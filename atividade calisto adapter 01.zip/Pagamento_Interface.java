package Som;

//a interface será o target
public interface Pagamento_Interface {
 public void pagar(double valor);

}
